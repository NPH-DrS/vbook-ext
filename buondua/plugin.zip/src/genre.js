function execute() {
    return Response.success([
        {title: "Chunmomo", input: "https://buondua.com/tag/蠢沫沫-10588", script: "gen.js"},
        {title: "Mini", input: "https://buondua.com/tag/糯美子mini-10387", script: "gen.js"},
        {title: "NinJA", input: "https://buondua.com/tag/ninja阿寨寨-11185", script: "gen.js"},
        {title: "Sayomomo", input: "https://buondua.com/tag/sayo-momo-11395", script: "gen.js"},
        {title: "Kang In-kyung", input: "https://buondua.com/tag/kang-in-kyung-10847", script: "gen.js"},
         {title: "UmekoJ", input: "https://buondua.com/tag/umekoj-11152", script: "gen.js"},
         {title: "Son Ye-Eun", input: "https://buondua.com/tag/son-ye-eun-10842", script: "gen.js"},
         {title: "Sally多啦雪", input: "https://buondua.com/tag/sally%E5%A4%9A%E5%95%A6%E9%9B%AA-11037", script: "gen.js"},
         {title: "陈小花 - Trần Tiểu Hoa", input: "https://buondua.com/tag/陈小花-11726", script: "gen.js"},
        {title: "小瑶幺幺 - Tiểu yêu Dao Dao", input: "https://buondua.com/tag/%E5%B0%8F%E7%91%B6%E5%B9%BA%E5%B9%BA-11652", script: "gen.js"},
         {title: "小恩 - Tiểu Ân", input: "https://buondua.com/tag/%E5%B0%8F%E6%81%A9-11611", script: "gen.js"},
          {title: "Ain Nguyen", input: "https://buondua.com/tag/ain-nguyen-11068", script: "gen.js"},
    ]);
}