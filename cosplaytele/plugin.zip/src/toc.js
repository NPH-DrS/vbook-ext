// mục lục 
load('config.js');
function execute(url) {
    return Response.success([
           {name: "1", url,  host: BASE_URL},
    ]);
}